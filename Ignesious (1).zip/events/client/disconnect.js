//here the event starts
module.exports = client => {
    console.log(`You have been disconnected at ${new Date()}.`.dim)
}
